#define MAJOR_INT 1
#define MINOR_INT 2
#define BUILD_INT 4
#define SPECIAL_INT 0

#define BUILD_NUMBER "1.2.4.0"



#ifdef _WITH_REGISTRY
#define PLUGIN_NAME " MS RC4 Encryption Plugin "
#define DSM_NAME " MSRC4Plugin.dsm "
#else
#define PLUGIN_NAME " MS RC4 Encryption Plugin "
#define DSM_NAME " MSRC4Plugin.dsm "
#endif
