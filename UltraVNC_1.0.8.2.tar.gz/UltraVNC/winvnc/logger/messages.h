//
//  Values are 32 bit values laid out as follows:
//
//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +---+-+-+-----------------------+-------------------------------+
//  |Sev|C|R|     Facility          |               Code            |
//  +---+-+-+-----------------------+-------------------------------+
//
//  where
//
//      Sev - is the severity code
//
//          00 - Success
//          01 - Informational
//          10 - Warning
//          11 - Error
//
//      C - is the Customer code flag
//
//      R - is a reserved bit
//
//      Facility - is the facility code
//
//      Code - is the facility's status code
//
//
// Define the facility codes
//


//
// Define the severity codes
//


//
// MessageId: MY_MSG1
//
// MessageText:
//
// 
// %1
//
#define MY_MSG1                          0x00640001L

//
// MessageId: MY_MSG2
//
// MessageText:
//
// 
// %1
//
#define MY_MSG2                          0x00640002L

//
// MessageId: MY_MSG3
//
// MessageText:
//
// 
// %1
//
#define MY_MSG3                          0x00640003L

